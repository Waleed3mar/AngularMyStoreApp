MyStore App

This app is about Store with some products on it, you could choose the amount you want to
add to your cart.

## Installation

1. you should cd to the app folder 

2. install npm 

```python
npm i
```
3. Now You can serve the app with
```bash
ng serve
```

## Usage
the app is too simple, just choose your products and add them to your cart then submit your order after filling out the form


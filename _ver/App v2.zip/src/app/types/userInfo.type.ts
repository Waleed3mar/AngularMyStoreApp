export type userInfo = {

   name:string;
   address:string;
   card:number;
   total:number;

    
}
import { Component, OnInit } from '@angular/core';
import { ConfirmService } from '../confirm.service';

@Component({
  selector: 'app-confirmation',
  templateUrl: './confirmation.component.html',
  styleUrls: ['./confirmation.component.css']
})
export class ConfirmationComponent implements OnInit {
  user:any = []

  name='';
  address='';
  total=0;

  constructor(private confirm:ConfirmService) { }

  ngOnInit(): void {
    this.user = this.confirm.getUser()
  
    
    // this.name = this.confirm.name
    // this.address = this.confirm.address
    // this.total = this.confirm.Total
  }

}

import { Injectable } from '@angular/core';
// import { Observable } from 'rxjs';
import { Item } from '../models/item';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  products: Item[] = []
  quantity =''

  constructor() { 
  }


  getCart() {
    return [
      this.products, 
      this.quantity
    ]
  }

  addToCart(product: Item) {
    this.products.push(product)

    return this.products;

  }

  

  removeFromCart(): void{
    
  }
}

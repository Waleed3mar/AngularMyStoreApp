import { Component, OnInit, Input } from '@angular/core';
import { Item } from '../models/item';
import { CartService } from '../services/cart.service';


@Component({
  selector: 'app-product-item',
  templateUrl: './product-item.component.html',
  styleUrls: ['./product-item.component.css']
})
export class ProductItemComponent implements OnInit {

@Input() item: Item;

quantity= ''
z=false;

  constructor(private cartService:CartService) { 
    this.item = {
    id: 1,
    name: '',
    price: 0,
    url: '',
    description:'',
    quantity:0
      }
  }

  ngOnInit(): void {

  }

  addToCart(item:Item): void{
    this.cartService.addToCart(item);

    if (!this.z){this.item.quantity = 1}

    window.alert('item added')
    
  }

  onSelected(value:string): void {
    
		this.item.quantity = parseInt(value) ;
    this.z = true;
  
	}

}

import { Component, Input, OnInit } from '@angular/core';
import { Item } from '../models/item';
import { CartService } from '../services/cart.service';
import { ConfirmService } from '../confirm.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  products: Item[] = [];
  // quantity = 0
  test:any = [];
  totalPrice=0

  //confirmation values
  name=''
  address=''
  total=0
  

  constructor(private cartService:CartService, private confirm:ConfirmService) {}

  ngOnInit(): void {
    this.test = this.cartService.getCart()
    this.products = this.test[0];
    // this.quantity = this.test[1];
    

    for(let i=0;i<this.products.length; i++){
      const x = this.products[i];
      this.totalPrice += ( x.quantity * x.price); 
    }
    // this.products = this.cartService.getCart()[0]
    // this.quantity = this.cartService.getCart()[1]
  }
  onSubmit() {
    this.confirm.addToConfirm(this.name, this.address, this.total)
  }

}

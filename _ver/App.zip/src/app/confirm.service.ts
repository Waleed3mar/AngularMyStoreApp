import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ConfirmService {
  
  name =''
  address =''
  Total = 0;

  constructor(private http:HttpClient) { }

  addToConfirm(name: string, address:string, total:number): void{
    this.name="name";
    this.address=address;
    this.Total=total;
  }

  getUser(){
    return [
      this.name,
      this.address,
      this.Total
    ]
  }
}
